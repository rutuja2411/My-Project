import java.io.IOException;




import java.awt.Toolkit;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.TooManyListenersException;

import javax.comm.CommPortIdentifier;
import javax.comm.PortInUseException;
import javax.comm.SerialPort;
import javax.comm.SerialPortEvent;
import javax.comm.SerialPortEventListener;
import javax.comm.UnsupportedCommOperationException;
import java.awt.event.*;
import java.applet.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.net.MalformedURLException;
  
class SimpleRead1 implements Runnable, SerialPortEventListener {
  static CommPortIdentifier portId;
  static Enumeration portList;
  static String stopTime = "";
  static String startTime = "";
  InputStream inputStream;
  SerialPort serialPort;
  Thread readThread;
  static String startDay = "";
  static String rf="";
  public static void main(String[] args) throws MalformedURLException {
    // String response = CallSMScAPI.SMSSender("adugar", "abc@123", "917276070701", "message", "WebSMS", "0");        
  
    portList = CommPortIdentifier.getPortIdentifiers();

    while (portList.hasMoreElements()) {
      portId = (CommPortIdentifier) portList.nextElement();
      if (portId.getPortType() == CommPortIdentifier.PORT_SERIAL) {
        if (portId.getName().equals("COM3")) {
          // if (portId.getName().equals("/dev/term/a")) {
          SimpleRead1 reader = new SimpleRead1();
        }
      }
    }
  }

  public SimpleRead1() {
    try {
      serialPort = (SerialPort) portId.open("SimpleReadApp", 2000);
    } catch (PortInUseException e) {
      System.out.println(e);
    }
    try {
      inputStream = serialPort.getInputStream();
    } catch (IOException e) {
      System.out.println(e);
    }
    try {
      serialPort.addEventListener(this);
    } catch (TooManyListenersException e) {
      System.out.println(e);
    }
    serialPort.notifyOnDataAvailable(true);
    try {
      serialPort.setSerialPortParams(9600, SerialPort.DATABITS_8,
          SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
    } catch (UnsupportedCommOperationException e) {
      System.out.println(e);
    }
    readThread = new Thread(this);
    readThread.start();
  }

  public void run() {
    try {
      Thread.sleep(20000);
    } catch (InterruptedException e) {
      System.out.println(e);
    }
  }

  public void serialEvent(SerialPortEvent event) {
    switch (event.getEventType()) {
    case SerialPortEvent.BI:
    case SerialPortEvent.OE:
    case SerialPortEvent.FE:
    case SerialPortEvent.PE:
    case SerialPortEvent.CD:
    case SerialPortEvent.CTS:
    case SerialPortEvent.DSR:
    case SerialPortEvent.RI:
    case SerialPortEvent.OUTPUT_BUFFER_EMPTY:
      break;
    case SerialPortEvent.DATA_AVAILABLE:
      byte[] readBuffer = new byte[100];

      try {
        while (inputStream.available() > 0) {
          int numBytes = inputStream.read(readBuffer);
        }
        rf="";
        String r = new String(readBuffer);
        System.out.println(rf.trim()+"_______" );

      rf=rf.replaceAll(" ", "")+r.trim().replaceAll(" ", "");
      System.out.println(rf);
        if(rf.length() == 8)
        {
          System.out.println(readBuffer+"-----------GGGGGGGGGGGGGGGGGGG--------------------"
               +rf);
            insert(rf);
            rf = "";
        }else if(rf.contains("Not")){
          System.out.println("-----------GGGGGGGGGGGGGGGGGGG--------------------"
               +rf);
          AudioClip ac = Applet.newAudioClip(new File("C:\\a.wav").toURL());
          ac.play();
    
        }
            
          
      } catch (IOException e) {
        System.out.println(e);
      }
      break;
    }
  }

  private void insert(String value) {
    // TODO Auto-generated method stub
    int rows = 0;
    String lon1 = null,lat1=null;
    
    Connection conn = getConnection();
    String selectquery = "select longitude,latitude from ms_location order by location_id desc limit 1";
    PreparedStatement pstmt = null;
    try {
      pstmt = conn.prepareStatement(selectquery);
      ResultSet rs = pstmt.executeQuery();
      if(rs.next())
      {
        lon1 = rs.getString(1);
        lat1 = rs.getString(2);
        selectquery = "select * from pay where rfid = ?";
        PreparedStatement pstmt1 = null;
        pstmt1 = conn.prepareStatement(selectquery);
        pstmt1.setString(1,value); 
        ResultSet rs1 = pstmt1.executeQuery();
        
        if(rs1.next())
        {
          String lon2 = rs1.getString(2);
          String lat2 = rs1.getString(3);
          
          
          System.out.println(lon2 + "Startlon" + lon1);
          System.out.println(lat2 + "Startlat" + lat1);
          double theta =Double.parseDouble(lon1) - Double.parseDouble(lon2);
          double dist = Math. sin(deg2rad(lat1)) * Math. sin(deg2rad(lat2)) + Math. cos(deg2rad(lat1)) * Math. cos(deg2rad(lat2)) * Math. cos(deg2rad(theta+""));
          dist = Math. acos(dist);
          dist = rad2deg(dist+"");
          dist = dist * 60 * 1.1515;
          
          if(dist==0)
            dist =1;
          double money = (int)(dist*10);
          if(money>30)
            money =30;
          else
            money =20;
          selectquery = "update  pay  set money=?, flag=? where rfid = ?";
          PreparedStatement pstmt2 = null;
          pstmt2 = conn.prepareStatement(selectquery);
          pstmt2.setString(1,(dist*10+""));
          pstmt2.setString(3,(value));
          pstmt2.setString(2,("5"));
          pstmt2.executeUpdate();
          
          selectquery = "update  rfid  set balance=balance - ? where id = ?";
          PreparedStatement pstmt3 = null;
          pstmt3 = conn.prepareStatement(selectquery);
          pstmt3.setString(1,money+"");
          pstmt3.setString(2,(value));
          pstmt3.executeUpdate();
          
          
          
        }else{
          
          
           String tripname = "";
           selectquery = "select * from trip";
           PreparedStatement pstmt4 = null;
            try {
              pstmt4 = conn.prepareStatement(selectquery);
               rs1 = pstmt4.executeQuery();
              
              if(rs1.next())
              {
                 tripname = rs1.getString(1);
              }
            }catch (Exception e) {
              // TODO: handle exception
            }
            selectquery = "select * from rfid where id = ?";
            PreparedStatement pstmt7 = null;
            pstmt7 = conn.prepareStatement(selectquery);
            pstmt7.setString(1,value); 
            ResultSet rs7 = pstmt7.executeQuery();
            if(rs7.next())
            {
            if(rs7.getInt(3)>30)
            {
           selectquery = "insert into pay values(?,?,?,?,?,?)";
           pstmt4 = null;
          
          try {
            pstmt4 = conn.prepareStatement(selectquery);
            pstmt4.setString(1, value);
            pstmt4.setString(2, lon1);
            pstmt4.setString(3, lat1);
            pstmt4.setString(4, "0");
            pstmt4.setString(5, "0");
            pstmt4.setString(6, tripname);
            pstmt4.executeUpdate();
          }
          catch (Exception e) {
            // TODO: handle exception
            
            
            e.printStackTrace();
          }}else{
            selectquery = "insert into pay values(?,?,?,?,?,?)";
             pstmt4 = null;
            
            try {
              pstmt4 = conn.prepareStatement(selectquery);
              pstmt4.setString(1, value);
              pstmt4.setString(2, lon1);
              pstmt4.setString(3, lat1);
              pstmt4.setString(4, "3");
              pstmt4.setString(5, "0");
              pstmt4.setString(6, tripname);
              pstmt4.executeUpdate();
            }
            catch (Exception e) {
              // TODO: handle exception
              
              
              e.printStackTrace();
            }
            
          }
            
            }else{
              System.out.println("Invalid card");
              Toolkit.getDefaultToolkit().beep();
              Toolkit.getDefaultToolkit().beep();
              Toolkit.getDefaultToolkit().beep();
              
            }
        }
        }
        
      
      

      System.out.println(pstmt.toString());

      
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        pstmt.close();

        conn.close();
      } catch (SQLException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
      }

    }

  }
  /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
  /*::  This function converts decimal degrees to radians             :*/
  /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
  private double deg2rad(String deg) {
    return  (Double.parseDouble( deg) * Math.PI / 180.0);
  }

  /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
  /*::  This function converts radians to decimal degrees             :*/
  /*:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
  private double rad2deg(String rad) {
    return (Double.parseDouble( rad) * 180.0 / Math.PI);
  }
  String username = "root";
  String password = "tiger";
  static final String DB_URL = "jdbc:mysql://localhost/gpstracking";

  public Connection getConnection() {
    Connection conn = null;
    try {
      // STEP 2: Register JDBC driver
      Class.forName("com.mysql.jdbc.Driver");

      // STEP 3: Open a connection
      System.out.println("Connecting to database...");
      conn = DriverManager.getConnection(DB_URL, username, password);
    } catch (Exception e) {
      // TODO: handle exception
      System.out.println("Unable to connect Database");
    }
    return conn;
  }

}